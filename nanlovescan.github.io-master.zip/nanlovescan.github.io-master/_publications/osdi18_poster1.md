---
title: "Ledger: Increasing Performance of POSIX Applications on Persistent Memory"
collection: publications
permalink: /publications/osdi18_poster1
venue: 'The 13th USENIX Symposium on Operating Systems Design and Implementation (OSDI 2018)'
date: 2018-10-08
citation: 'Rohan Kadekodi, <strong>Se Kwon Lee</strong>, Aasheesh Kolli, and Vijay Chidambaram, <font color="blue"><strong>Poster</strong></font> at <i>the 13th USENIX Symposium on Operating Systems Design and Implementation</i> (<strong>OSDI 2018</strong>).'
---
