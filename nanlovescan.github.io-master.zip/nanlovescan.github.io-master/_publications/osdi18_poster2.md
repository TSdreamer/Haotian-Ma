---
title: "Software challenges for persistent fabric-attached memory"
collection: publications
permalink: /publications/osdi18_poster2
venue: 'The 13th USENIX Symposium on Operating Systems Design and Implementation (OSDI 2018)'
date: 2018-10-08
citation: 'Haris Volos, Kimberly Keeton, Yupu Zhang, Milind Chabbi, <strong>Se Kwon Lee</strong>, Mark Lillibridge, Yuvraj Patel, and Wei Zhang, <font color="blue"><strong>Poster</strong></font> at <i>the 13th USENIX Symposium on Operating Systems Design and Implementation</i> (<strong>OSDI 2018</strong>).'
---
