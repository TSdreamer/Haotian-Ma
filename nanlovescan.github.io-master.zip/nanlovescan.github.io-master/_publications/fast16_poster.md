---
title: "Adapting Legacy File Systems to Work Efficiently for Persistent Memory based Storage"
collection: publications
permalink: /publications/fast16_poster
venue: 'The 14th USENIX Conference on File and Storage Technology (FAST 2016)'
date: 2017-02-22
citation: 'Hyunsub Song, Young Je Moon, <strong>Se Kwon Lee</strong>, and Sam H. Noh, <font color="blue"><strong>Poster</strong></font> at <i>the 14th USENIX Conference on File and Storage Technology</i> (<strong>FAST 2016</strong>).'
---
