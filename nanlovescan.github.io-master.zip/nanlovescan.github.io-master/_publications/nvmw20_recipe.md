---
title: "RECIPE : Converting Concurrent DRAM Indexes to Persistent-Memory Indexes"
collection: publications
permalink: /publications/nvmw20_recipe
venue: 'The 11th Annual Non-Volatile Memories Workshop (NVMW 2020)'
date: 2020-03-08
citation: '<strong>Se Kwon Lee</strong>, Jayashree Mohan, Sanidhya Kashyap, Taesoo Kim, and Vijay Chidambaram, <i>The 11th Annual Non-Volatile Memories Workshop</i> (<strong>NVMW 2020</strong>, Extended abstract of SOSP 2019 paper).'
---
[[pdf]](http://sekwonlee.github.io/files/nvmw20_recipe.pdf)
