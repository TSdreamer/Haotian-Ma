---
title: "WORT: Write Optimal Radix Tree for Persistent Memory Storage Systems"
collection: publications
permalink: /publications/nvmw17_wort
venue: 'The 8th Annual Non-Volatile Memories Workshop (NVMW 2017)'
date: 2017-03-12
citation: '<strong>Se Kwon Lee</strong>, K. Hyun Lim, Hyunsub Song, Beomseok Nam, and Sam H. Noh, <i>The 8th Annual Non-Volatile Memories Workshop</i> (<strong>NVMW 2017</strong>, Extended abstract of FAST 2017 paper).'
---
[[pdf]](http://sekwonlee.github.io/files/nvmw17_wort.pdf)
[[slides]](http://sekwonlee.github.io/files/nvmw17_wort_slide.pdf)
