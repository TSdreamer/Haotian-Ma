---
title: "Memory-Oriented Distributed Computing at Rack Scale"
collection: publications
permalink: /publications/socc18_poster
venue: 'The 9th ACM Symposium on Cloud Computing (SOCC 2018)'
date: 2018-10-11
citation: 'Haris Volos, Kimberly Keeton, Yupu Zhang, Milind Chabbi, <strong>Se Kwon Lee</strong>, Mark Lillibridge, Yuvraj Patel, and Wei Zhang, <font color="blue"><strong>Poster</strong></font> at <i>the 9th ACM Symposium on Cloud Computing</i> (<strong>SOCC 2018</strong>).'
---
