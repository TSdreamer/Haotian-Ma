---
title: "Spring 2016 TA for Objec-Oriented Programming"
collection: teaching
type: "Undergraduate course"
permalink: /teaching/2016-spring-TA
venue: "UNIST (Ulsan National Institute of Science & Technology), Computer Science and Engineering"
date: 2016-03-01
location: "Ulsan, Republic of Korea"
---
The main focus of this course is to develop object-oriented programming skills and to make students comfortable with C++ class implementation. This course requires students to implement a large number of small to medium-sized programs.
