---
title: "Spring 2020 TA for Distributed Systems (CS 380D)"
collection: teaching
type: "Graduate course"
permalink: /teaching/2020-spring-TA
venue: "The University of Texas at Austin, Computer Science"
date: 2020-01-28
location: "Austin, Texas, United States of America"
---
This is a course designed to expose graduate students to the basics of distributed systems.
