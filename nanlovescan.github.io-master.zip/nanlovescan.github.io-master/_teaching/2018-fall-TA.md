---
title: "Fall 2018 TA for Elements of Software Design (CS 313E)"
collection: teaching
type: "Undergraduate course"
permalink: /teaching/2018-fall-TA
venue: "The University of Texas at Austin, Computer Science"
date: 2018-09-01
location: "Austin, Texas, United States of America"
---
This is the second course in the Elements of Software series. The emphasis of this course is on software development using object-oriented methodology. This course includes how to design software, how to create reusable software components, and how to compose programs from already available components. Furthermore, students learn about some basic data structures and algorithms and how to match the data structures and algorithms to problems.
